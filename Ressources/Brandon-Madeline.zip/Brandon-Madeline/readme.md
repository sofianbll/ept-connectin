# Connect'In

A social network application for companies and ESNs built with React and Laravel.

## Features

- User authentication and registration
- Create, edit, and delete posts with image upload
- Like and unlike posts
- Comment on posts, edit and delete comments
- User avatars
- User profile management

## Tech Stack

- **Frontend**: React, Vite, Tailwind CSS, React Router, Axios
- **Backend**: Laravel, PHP 8.4, MySQL 8.0
- **Containerization**: Docker & Docker Compose

## Prerequisites

- Docker
- Docker Compose

## Installation

1. **Clone the repository**

   ```bash
   git clone <repository-url>
   cd W-WEB-103-PAR-1-1-connect_in-13
   ```

2. **Start the application**

   ```bash
   docker-compose up
   ```

   This will:
   - Build and start all containers (PHP, Nginx, React, MySQL)
   - Run database migrations automatically
   - Create necessary storage links

3. **Access the application**
   - **Frontend**: http://localhost:5173
   - **Backend API**: http://localhost:8000/api
   - **Database**: localhost:3306 (user: `connectin_user`, password: `connectin_password`)

## Usage

1. Register a new account or login
2. Create posts with optional images
3. Like, comment, and edit your content
4. Customize your profile with an avatar

## Stopping the Application

```bash
docker-compose down
```

To completely reset (including database):

```bash
docker-compose down -v
```
