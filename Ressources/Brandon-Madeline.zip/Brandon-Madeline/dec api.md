### Communication API (contrat backend ↔ frontend)

Tous les endpoints sont préfixés par `/api/`. Le token Sanctum est envoyé dans le header `Authorization: Bearer {token}`.

#### Auth

| Méthode | Endpoint           | Body                                                              | Réponse         |
| ------- | ------------------ | ----------------------------------------------------------------- | --------------- |
| POST    | `/api/register`    | `{first_name, last_name, email, password, password_confirmation}` | `{user, token}` |
| POST    | `/api/login`       | `{email, password}`                                               | `{user, token}` |
| POST    | `/api/logout`      | —                                                                 | `{message}`     |
| GET     | `/api/me`          | —                                                                 | `{user}`        |
| PUT     | `/api/me`          | `{first_name?, last_name?, email?}`                               | `{user}`        |
| PUT     | `/api/me/password` | `{current_password, password, password_confirmation}`             | `{message}`     |
| DELETE  | `/api/me`          | `{delete_content: boolean}`                                       | `{message}`     |

#### Posts

| Méthode | Endpoint          | Body                          | Réponse                      |
| ------- | ----------------- | ----------------------------- | ---------------------------- |
| GET     | `/api/posts`      | —                             | `{data: [post], pagination}` |
| POST    | `/api/posts`      | FormData: `{content, image?}` | `{post}`                     |
| GET     | `/api/posts/{id}` | —                             | `{post with comments}`       |
| PUT     | `/api/posts/{id}` | `{content?, image?}`          | `{post}`                     |
| DELETE  | `/api/posts/{id}` | —                             | `{message}`                  |

#### Likes

| Méthode | Endpoint               | Body | Réponse                           |
| ------- | ---------------------- | ---- | --------------------------------- |
| POST    | `/api/posts/{id}/like` | —    | `{liked: bool, likes_count: int}` |

#### Commentaires

| Méthode | Endpoint                   | Body        | Réponse     |
| ------- | -------------------------- | ----------- | ----------- |
| GET     | `/api/posts/{id}/comments` | —           | `[comment]` |
| POST    | `/api/posts/{id}/comments` | `{content}` | `{comment}` |
| PUT     | `/api/comments/{id}`       | `{content}` | `{comment}` |
| DELETE  | `/api/comments/{id}`       | —           | `{message}` |

#### Format d'un Post (JSON retourné)

```json
{
  "id": 1,
  "content": "Mon premier post !",
  "image_url": "http://localhost:8000/storage/posts/abc123.jpg",
  "created_at": "2026-02-25T10:00:00Z",
  "updated_at": "2026-02-25T10:00:00Z",
  "author": {
    "id": 1,
    "first_name": "Jean",
    "last_name": "Dupont"
  },
  "likes_count": 5,
  "comments_count": 3,
  "liked_by_user": true
}
```

#### Format d'un Commentaire (JSON retourné)

```json
{
  "id": 1,
  "content": "Super post !",
  "created_at": "2026-02-25T10:05:00Z",
  "updated_at": "2026-02-25T10:05:00Z",
  "author": {
    "id": 2,
    "first_name": "Marie",
    "last_name": "Martin"
  }
}
```
