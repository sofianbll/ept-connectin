import axios from "axios";

// Créer une instance axios avec la base URL de l'API
const api = axios.create({
  baseURL: "http://localhost:8000/api",
  headers: {
    "Content-Type": "application/json",
  },
});

// Intercepteur de requête : ajouter le token d'authentification et gérer Content-Type
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    // Let axios set the correct Content-Type for FormData (multipart/form-data with boundary)
    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
    }
    return config;
  },
  (error) => Promise.reject(error),
);

// Intercepteur de réponse : gérer les erreurs
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Si erreur 401, supprimer le token et recharger
    // Mais ne pas rediriger si on est déjà sur /login ou /register (pour laisser le composant gérer l'erreur)
    if (error.response && error.response.status === 401) {
      const currentPath = window.location.pathname;

      // Seulement rediriger si on n'est pas déjà sur une page d'auth
      if (currentPath !== "/login" && currentPath !== "/register") {
        localStorage.removeItem("token");
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  },
);

export default api;
