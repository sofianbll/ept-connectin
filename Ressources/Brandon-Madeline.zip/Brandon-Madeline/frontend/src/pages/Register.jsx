import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { ToastContainer, toast, Slide } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sky from '../assets/sky.jpg';
import logo from '../assets/modernci.png';

export default function Register() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [passwordConfirmation, setPasswordConfirmation] = useState("");
  const { register } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const toastError = {
    position: "top-center",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
    transition: Slide,
  };

  const toastSuccess = {
    position: "top-center",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Slide,
  }


  async function handleSubmit(e) {
    e.preventDefault();

    if (!firstName.trim()) {
      toast.error("First name is required", toastError);
      return;
    }

    if (!lastName.trim()) {
      toast.error("Last name is required", toastError);
      return;
    }

    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email address", toastError);
      return;
    }

    if (password.length < 8) {
      toast.error("Password must be at least 8 characters", toastError);
      return;
    }

    if (password.length > 64) {
      toast.error("Password must be less than 64 characters", toastError);
      return;
    }

    if (password !== passwordConfirmation) {
      toast.error("Passwords do not match", toastError);
      return;
    }

    try {
      setLoading(true);
      await register(firstName, lastName, email, password);
      toast.success("Account created! Redirecting…", toastSuccess);
      // Petite pause pour laisser le toast s’afficher avant la navigation
      setTimeout(() => navigate("/"), 1500);
    } catch (error) {
      console.error("Registration error:", error);
      const msg = error?.message ?? "Something went wrong. Please try again.";
      toast.error(msg, toastError);
    } finally {
      setLoading(false);
    }

  };

  return (
    <>
      <div className="flex">
        <img
          className="fixed inset-0 w-full h-full object-cover -z-10"
          src={Sky}
          alt="sky background"
        />

        <div className="absolute flex top-0 left-0 backdrop-blur-3xl w-2xl h-full justify-center items-center text-center lg:overflow-scroll">

          <form
            onSubmit={handleSubmit}
            className="flex md:w-96 w-80 flex-col items-center justify-center">

            <h2 className="text-4xl text-gray-900 font-medium mb-3">Connect'In: Registration</h2>

            <p className="text-sm text-gray-700/90 mt-3 mb-3">Welcome to Connect'In! To join your team, please fill out the form below</p>

            <div className="flex items-center w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2 mt-5">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 8a3 3 0 100-6 3 3 0 000 6Z" fill="#6B7280" />
                <path d="M3 14c0-2.761 2.239-5 5-5s5 2.239 5 5v1H3v-1Z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="text"
                name="first_name"
                placeholder="First Name"
                autoComplete="First Name"
                maxlenght="32"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
            </div>

            <div className="flex items-center w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2 mt-5">
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 8a3 3 0 100-6 3 3 0 000 6Z" fill="#6B7280" />
                <path d="M3 14c0-2.761 2.239-5 5-5s5 2.239 5 5v1H3v-1Z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="text"
                name="last_name"
                placeholder="Last Name"
                autoComplete="Last Name"
                maxlenght="32"
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
              />
            </div>

            <div className="flex items-center w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2 mt-5">
              <svg width="16" height="11" viewBox="0 0 16 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd" d="M0 .55.571 0H15.43l.57.55v9.9l-.571.55H.57L0 10.45zm1.143 1.138V9.9h13.714V1.69l-6.503 4.8h-.697zM13.749 1.1H2.25L8 5.356z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="email"
                name="email"
                placeholder="Email"
                autoComplete="email"
                maxlenght="96"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="flex items-center mt-6 w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2">
              <svg width="13" height="17" viewBox="0 0 13 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 8.5c0-.938-.729-1.7-1.625-1.7h-.812V4.25C10.563 1.907 8.74 0 6.5 0S2.438 1.907 2.438 4.25V6.8h-.813C.729 6.8 0 7.562 0 8.5v6.8c0 .938.729 1.7 1.625 1.7h9.75c.896 0 1.625-.762 1.625-1.7zM4.063 4.25c0-1.406 1.093-2.55 2.437-2.55s2.438 1.144 2.438 2.55V6.8H4.061z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="password"
                name="password"
                autoComplete="new-password"
                placeholder="Password"
                pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <div className="flex items-center mt-6 w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2">
              <svg width="13" height="17" viewBox="0 0 13 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 8.5c0-.938-.729-1.7-1.625-1.7h-.812V4.25C10.563 1.907 8.74 0 6.5 0S2.438 1.907 2.438 4.25V6.8h-.813C.729 6.8 0 7.562 0 8.5v6.8c0 .938.729 1.7 1.625 1.7h9.75c.896 0 1.625-.762 1.625-1.7zM4.063 4.25c0-1.406 1.093-2.55 2.437-2.55s2.438 1.144 2.438 2.55V6.8H4.061z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="password"
                name="password_confirmation"
                placeholder="Confirm Password"
                autoComplete="new-password"
                value={passwordConfirmation}
                onChange={(e) => setPasswordConfirmation(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className={`mt-8 w-full h-11 rounded-full shadow-lg text-white bg-black hover:opacity-80 transition-opacity 
                  ${loading ? "bg-black cursor-not-allowed" : "bg-black hover:opcity-80"}`}
            >
              {loading ? "Connecting…" : "Register"}
            </button>

            <div className="flex items-center gap-4 w-full mb-3 mt-10">
              <div className="w-full h-px bg-gray-300/90"></div>
              <p className="w-full text-nowrap text-sm text-gray-500/90">or <Link to="/login" className="text-black">sign in</Link></p>
              <div className="w-full h-px bg-gray-300/90"></div>
            </div>

          </form>
        </div>

        <div className="absolute bottom-0 right-3">
          <img src={logo} className="h-30 w-30" />
        </div>

      </div>
      <ToastContainer />
    </>
  );
};