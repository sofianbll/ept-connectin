import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Link } from "react-router-dom";
import { ToastContainer, toast, Slide } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sky from '../assets/sky.jpg';
import logo from '../assets/modernci.png';

export default function Login() {

  // Initialize two state variables for email and password inputs
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  // Get the login function from the authentication context
  const { login } = useAuth();
  // Manage navigation after successful login
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const toastError = {
    position: "top-center",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "light",
    transition: Slide,
  };

  const toastSuccess = {
    position: "top-center",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Slide,
  };

  // Handle form submission for login after pressing the "Se connecter" button
  async function manageSubmit(e) {
    e.preventDefault();

    if (!email.trim()) {
      toast.error("Please enter your email", toastError);
      return;
    }

    if (!emailRegex.test(email)) {
      toast.error("Your email is not valid", toastError);
      return;
    }

    if (!password.trim()) {
      toast.error("Please enter your password", toastError);
      return;
    }

    try {
      setLoading(true);
      await login(email, password);
      toast.success("Welcome back!", toastSuccess);
      setTimeout(() => navigate("/"), 1500);
    } catch (error) {
      toast.error("Your email or your password is incorrect, try again", toastError);
      const msg = error?.message ?? "Something went wrong. Please try again.";
      console.error("Login error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="relative min-h-screen w-full flex items-center justify-center">
        <img
          className="fixed inset-0 w-full h-full object-cover -z-10"
          src={Sky}
          alt="sky background"
        />
        <div className="absolute top-0 left-0 backdrop-blur-3xl w-2xl h-screen flex justify-center items-center text-center sm:h-screen overflow-scroll">

          <form
            onSubmit={manageSubmit}
            className="md:w-96 w-80 flex flex-col items-center justify-center">

            <h2 className="text-4xl text-gray-900 font-medium mb-3">Sign In</h2>

            <p className="text-sm text-gray-700/90 mt-3 mb-3">Welcome back! Please sign in to continue</p>

            <div className="flex items-center w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2 mt-5">
              <svg width="16" height="11" viewBox="0 0 16 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" clipRule="evenodd" d="M0 .55.571 0H15.43l.57.55v9.9l-.571.55H.57L0 10.45zm1.143 1.138V9.9h13.714V1.69l-6.503 4.8h-.697zM13.749 1.1H2.25L8 5.356z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
              />
            </div>

            <div className="flex items-center mt-6 w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2">
              <svg width="13" height="17" viewBox="0 0 13 17" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 8.5c0-.938-.729-1.7-1.625-1.7h-.812V4.25C10.563 1.907 8.74 0 6.5 0S2.438 1.907 2.438 4.25V6.8h-.813C.729 6.8 0 7.562 0 8.5v6.8c0 .938.729 1.7 1.625 1.7h9.75c.896 0 1.625-.762 1.625-1.7zM4.063 4.25c0-1.406 1.093-2.55 2.437-2.55s2.438 1.144 2.438 2.55V6.8H4.061z" fill="#6B7280" />
              </svg>
              <input
                className="bg-transparent text-gray-700/80 placeholder-gray-500/80 outline-none text-sm w-full h-full"
                type="password"
                autoComplete="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
              />
            </div>

            <button
              type="submit"
              className={`mt-8 w-full h-11 rounded-full shadow-lg text-white bg-black hover:opacity-80 transition-opacity 
                  ${loading ? "bg-black cursor-not-allowed" : "bg-black hover:opcity-80"}`}
            >
              {loading ? "Connecting…" : "Sign In"}
            </button>

            <div className="flex items-center gap-4 w-full mb-3 mt-10">
              <div className="w-full h-px bg-gray-300/90"></div>
              <p className="w-full text-nowrap text-sm text-gray-500/90">or <Link to="/register" className="text-black">register</Link> in with email</p>
              <div className="w-full h-px bg-gray-300/90"></div>
            </div>

          </form>
        </div>

        <div className="absolute bottom-0 right-3">
          <img src={logo} className="h-30 w-30" />
        </div>

      </div>
      <ToastContainer />
    </>
  );
};
