import { useState, useEffect } from "react";
import api from "../services/api";
import SideBar from "../components/Sidebar";
import Sky from "../assets/sky.jpg";
import { ToastContainer, toast, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Feed() {
  const [posts, setPosts] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [newPostContent, setNewPostContent] = useState("");
  const [newPostImage, setNewPostImage] = useState(null);
  const [expandedComments, setExpandedComments] = useState({});
  const [commentText, setCommentText] = useState({});
  const [editingPostId, setEditingPostId] = useState(null);
  const [editContent, setEditContent] = useState("");
  const [editImage, setEditImage] = useState(null);
  const [deleteCurrentImage, setDeleteCurrentImage] = useState(false);
  const [editingCommentId, setEditingCommentId] = useState(null);
  const [editingCommentContent, setEditingCommentContent] = useState("");

  //toasts design

  const toastError = {
    position: "top-right",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Slide,
  };

  const toastSuccess = {
    position: "top-right",
    autoClose: 3000,
    hideProgressBar: false,
    closeOnClick: false,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    theme: "dark",
    transition: Slide,
  };

  // ============ STATES POUR LA PAGINATION ============
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  // Fetch current user info
  const fetchCurrentUser = async () => {
    try {
      const response = await api.get("/me");
      setCurrentUser(response.data);
    } catch (error) {
      console.error("Error fetching current user", error);
      toast.error("Profile Error", toastError);
    }
  };

  // Fetch posts from the API with pagination (3 per page)
  const fetchPosts = async (page = 1) => {
    try {
      const response = await api.get(`/posts?page=${page}&per_page=3`);
      setPosts(response.data.data);
      setCurrentPage(response.data.current_page);
      setTotalPages(response.data.last_page);
      setTotal(response.data.total);
    } catch (error) {
      console.error("Error loading posts", error);
      toast.error("Error loading posts", toastError);
    }
  };

  const goToPage = (page) => {
    if (page >= 1 && page <= totalPages) {
      fetchPosts(page);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
    fetchPosts();
  }, []);

  const handleLike = async (post) => {
    try {
      const response = await api.post(`/posts/${post.id}/like`);

      setPosts(
        posts.map((p) => {
          if (p.id === post.id) {
            return {
              ...p,
              liked_by_user: response.data.liked,
              likes_count: response.data.likes_count,
            };
          }
          return p;
        }),
      );
    } catch (error) {
      console.error("Error liking post", error);
      toast.error("Oops, try liking again!", toastError);
    }
  };

  const handleDelete = async (postId) => {
    if (window.confirm("Are you sure you want to delete this post?")) {
      try {
        await api.delete(`/posts/${postId}`);
        setPosts(posts.filter((p) => p.id !== postId));
        toast.success("Post deleted!", toastSuccess);
      } catch (error) {
        console.error("Error deleting post", error);
        toast.error("Error deleting post", toastError);
      }
    }
  };

  const startEditPost = (post) => {
    setEditingPostId(post.id);
    setEditContent(post.content);
    setEditImage(null);
    setDeleteCurrentImage(false);
  };

  const cancelEditPost = () => {
    setEditingPostId(null);
    setEditContent("");
    setEditImage(null);
    setDeleteCurrentImage(false);
  };

  const handleEditPost = async (postId) => {
    if (!editContent.trim()) return;

    try {
      const formData = new FormData();
      formData.append("content", editContent);
      if (editImage) {
        formData.append("image", editImage);
      }
      if (deleteCurrentImage) {
        formData.append("delete_image", "true");
      }

      const response = await api.put(`/posts/${postId}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setPosts(posts.map((p) => (p.id === postId ? response.data : p)));
      setEditingPostId(null);
      setEditContent("");
      setEditImage(null);
      setDeleteCurrentImage(false);
      toast.success("Your post has been edited successfully", toastSuccess);
    } catch (error) {
      console.error("Error editing post", error);
      toast.error("Error editing post", toastError);
    }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    if (!newPostContent.trim()) return;

    try {
      const formData = new FormData();
      formData.append("content", newPostContent);
      if (newPostImage) {
        formData.append("image", newPostImage);
      }

      const response = await api.post("/posts", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      // Reload current page to reflect the new post
      await fetchPosts(1);
      setNewPostContent("");
      setNewPostImage(null);
      toast.success("You just posted!", toastSuccess);
    } catch (error) {
      console.error("Error creating post", error);
      toast.error("Your couldn't be created, try again", toastError);
    }
  };

  const handleAddComment = async (postId) => {
    const text = commentText[postId]?.trim();
    if (!text) return;

    try {
      const response = await api.post(`/posts/${postId}/comments`, {
        content: text,
      });

      setPosts(
        posts.map((p) => {
          if (p.id === postId) {
            return {
              ...p,
              comments: [response.data, ...(p.comments || [])],
            };
          }
          return p;
        }),
      );
      setCommentText({ ...commentText, [postId]: "" });
      toast.success("You just commented this post!", toastSuccess);
    } catch (error) {
      console.error("Error adding comment", error);
      toast.error("Error adding comment", toastError);
    }
  };

  const handleDeleteComment = async (postId, commentId) => {
    if (window.confirm("Delete this comment?")) {
      try {
        await api.delete(`/comments/${commentId}`);
        setPosts(
          posts.map((p) => {
            if (p.id === postId) {
              return {
                ...p,
                comments: p.comments.filter((c) => c.id !== commentId),
              };
            }
            return p;
          }),
        );
        toast.success("Your comment has been successfully deleted", toastSuccess);
      } catch (error) {
        console.error("Error deleting comment", error);
        toast.error("Your comment couldn't be deleted, try again", toastError);
      }
    }
  };

  const startEditComment = (comment) => {
    setEditingCommentId(comment.id);
    setEditingCommentContent(comment.content);
  };

  const cancelEditComment = () => {
    setEditingCommentId(null);
    setEditingCommentContent("");
  };

  const handleEditComment = async (postId, commentId) => {
    if (!editingCommentContent.trim()) return;

    try {
      const response = await api.put(`/comments/${commentId}`, {
        content: editingCommentContent,
      });

      setPosts(
        posts.map((p) => {
          if (p.id === postId) {
            return {
              ...p,
              comments: p.comments.map((c) => (c.id === commentId ? response.data : c)),
            };
          }
          return p;
        }),
      );
      setEditingCommentId(null);
      setEditingCommentContent("");
      toast.success("Your comment have been edited", toastSuccess);
    } catch (error) {
      console.error("Error editing comment", error);
      toast.error("Error editing comment", toastError);
    }
  };

  return (
    <>
      <img
        className="fixed inset-0 w-full h-full object-cover -z-10"
        src={Sky}
        alt="sky background"
      />
      <div className="absolute top-0 left-0 backdrop-blur-lg w-full h-screen flex">
        <SideBar />

        <div className="flex flex-col mt-5 w-full md:max-w-xl sm:ml-[280px] max-h-3/4 overflow-scroll mr-5">
          {posts.length === 0 && <p className="text-gray-950">No posts yet.</p>}

          {posts.map((post) => (
            <div key={post.id} className="bg-white/30 backdrop-blur-md p-4 sm:p-5 rounded-xl mb-5 shadow-lg">
              {/* Post author and date */}
              <div className="flex justify-between items-center mb-2 text-gray-800">
                <div className="flex items-center gap-2">
                  {post.user ? (
                    <>
                      {post.user.avatar ? (
                        <img
                          src={post.user.avatar}
                          alt="Avatar"
                          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover border border-white/50"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-lg">
                          {post.user.first_name?.[0]?.toUpperCase()}
                        </div>
                      )}
                      <p className="font-bold">
                        {post.user.first_name} {post.user.last_name}
                      </p>
                    </>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-full bg-gray-400 flex items-center justify-center text-white font-bold text-lg">
                        ?
                      </div>
                      <p className="font-bold text-gray-500 italic">Deleted User</p>
                    </>
                  )}
                </div>
                <span className="text-gray-800 text-sm">{new Date(post.created_at).toLocaleString()}</span>
              </div>

              {/* Post content or edit form */}
              {editingPostId === post.id ?
                <div className="mb-4 p-4 rounded-lg bg-white/40 shadow-2xs">
                  <textarea
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-lg mb-3 text-gray-950 focus:outline-none focus:border-gray-950"
                    rows="3"
                  />

                  {/* Current image preview */}
                  {post.image && !deleteCurrentImage && (
                    <div className="mb-3">
                      <img src={post.image} alt="Current" className="max-w-[120px] h-auto rounded mb-2" />
                      <button
                        type="button"
                        onClick={() => setDeleteCurrentImage(true)}
                        className="px-3 py-1 bg-red-500 hover:bg-red-300 text-white rounded text-sm font-medium transition-colors"
                      >
                        Remove current image
                      </button>
                    </div>
                  )}

                  {/* New image upload */}
                  {deleteCurrentImage || !post.image ?
                    <div className="flex items-center gap-2 mb-3">
                      <label className="px-3 py-2 bg-black text-white hover:bg-gray-300 rounded cursor-pointer text-sm font-medium transition-colors">
                        Choose file
                        <input type="file" accept="image/*" onChange={(e) => setEditImage(e.target.files[0])} className="hidden" />
                      </label>
                      <span className="text-xs text-gray-500">{editImage ? editImage.name : "No file chosen"}</span>
                    </div>
                    : null}

                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={cancelEditPost}
                      className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-500 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleEditPost(post.id)}
                      className="px-4 py-2 bg-black hover:bg-gray-950 text-white rounded-lg font-medium transition-colors"
                    >
                      Save
                    </button>
                  </div>
                </div>
                : <p className="flex justify-between ml-4 mt-2 text-base leading-relaxed text-black">{post.content}</p>}

              {/* Post image */}
              {post.image && (
                <div className="my-3">
                  <img src={post.image} alt="Post" className="max-w-full max-h-96 rounded" />
                </div>
              )}

              {/* Like and Comment buttons */}
              <div className="mt-4 flex justify-between items-center gap-6">
                <div className="flex">
                  <button onClick={() => handleLike(post)} className="flex items-center gap-1 hover:text-red-500 transition-colors">
                    <span className="text-2xl">{post.liked_by_user ? "❤️" : "🤍"}</span>
                    <span className="text-gray-800">{post.likes_count || 0}</span>
                  </button>
                  <button
                    onClick={() => setExpandedComments({ ...expandedComments, [post.id]: !expandedComments[post.id] })}
                    className="flex items-center gap-1 text-blue-500 hover:text-blue-700 transition-colors"
                  >
                    <span>💬</span>
                    <span className="text-gray-800">{post.comments?.length || 0}</span>
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  {currentUser?.user && Number(post.user?.id) === Number(currentUser.user.id) && (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => startEditPost(post)}
                        className="text-heading text-gray-800 bg-transparent box-border border border-transparent hover:bg-neutral-secondary-medium focus:ring-4 focus:ring-neutral-tertiary font-medium leading-5 rounded-base text-sm px-4 py-2.5 focus:outline-none"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(post.id)}
                        className="text-heading text-gray-800 bg-transparent box-border border border-transparent hover:text-red-700 transition-colors bg-neutral-secondary-medium focus:ring-4 focus:ring-neutral-tertiary font-medium leading-5 rounded-base text-sm px-4 py-2.5 focus:outline-none"
                      >
                        Delete
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Comments section */}
              {expandedComments[post.id] && (
                <div className="mt-4 border-t pt-4">
                  {/* Comments list */}
                  {post.comments && post.comments.length > 0 && (
                    <div className="mb-4 space-y-3">
                      {post.comments.map((comment) => (
                        <div key={comment.id} className="bg-white/40 p-3 rounded">
                          {
                            editingCommentId === comment.id ?
                              // Edit mode
                              <div className="space-y-2">
                                <textarea
                                  value={editingCommentContent}
                                  onChange={(e) => setEditingCommentContent(e.target.value)}
                                  className="w-full p-2 border border-gray-600 rounded text-sm text-black resize-y"
                                  rows="3"
                                />
                                <div className="flex gap-2 justify-end">
                                  <button
                                    onClick={cancelEditComment}
                                    className="px-3 py-1 border border-gray-300 rounded text-xs text-gray-800 hover:bg-gray-100 transition-colors"
                                  >
                                    Cancel
                                  </button>
                                  <button
                                    onClick={() => handleEditComment(post.id, comment.id)}
                                    className="px-3 py-1 bg-black hover:bg-gray-950 text-white rounded text-xs font-medium transition-colors"
                                  >
                                    Save
                                  </button>
                                </div>
                              </div>
                              // View mode
                              : <div className="flex justify-between flex-col gap-2">
                                <div className="flex flex-col items-start w-full">
                                  <div className="flex items-center gap-2 mb-1">
                                    {comment.user ? (
                                      <>
                                        {comment.user.avatar ? (
                                          <img
                                            src={comment.user.avatar}
                                            alt="Avatar"
                                            className="w-8 h-8 rounded-full object-cover border border-white/50"
                                          />
                                        ) : (
                                          <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-sm">
                                            {comment.user.first_name?.[0]?.toUpperCase()}
                                          </div>
                                        )}
                                        <span className="text-sm text-gray-950 font-bold">
                                          {comment.user.first_name} {comment.user.last_name}
                                        </span>
                                      </>
                                    ) : (
                                      <>
                                        <div className="w-8 h-8 rounded-full bg-gray-400 flex items-center justify-center text-white font-bold text-sm">
                                          ?
                                        </div>
                                        <span className="text-sm text-gray-500 italic font-bold">
                                          Deleted User
                                        </span>
                                      </>
                                    )}
                                  </div>
                                  <p className="text-sm text-gray-600 ml-10">{comment.content}</p>
                                </div>

                                <div className="flex justify-between items-center gap-6">
                                  <span className="text-xs text-gray-400">{new Date(comment.created_at).toLocaleString()}</span>

                                  {currentUser?.user && Number(comment.user?.id) === Number(currentUser.user.id) && (
                                    <div className="flex">
                                      <button
                                        onClick={() => startEditComment(comment)}
                                        className="text-black hover:text-gray-950 text-xs font-medium transition-colors"
                                      >
                                        Edit
                                      </button>
                                      <button
                                        onClick={() => handleDeleteComment(post.id, comment.id)}
                                        className="text-black hover:text-red-700 text-xs font-medium transition-colors"
                                      >
                                        Delete
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>

                          }
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Add comment form */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={commentText[post.id] || ""}
                      onChange={(e) => setCommentText({ ...commentText, [post.id]: e.target.value })}
                      placeholder="Add a comment..."
                      className="flex-1 p-2 border border-gray-300 rounded text-sm text-gray-800 focus:outline-none focus:border-gray-950"
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          handleAddComment(post.id);
                        }
                      }}
                    />
                    <button
                      onClick={() => handleAddComment(post.id)}
                      className="px-3 py-2 bg-black hover:bg-gray-950 text-white rounded text-sm font-medium transition-colors"
                    >
                      Post
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 mb-10 py-3">
              <button
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
                className={`w-9 h-9 flex items-center justify-center rounded-full text-sm font-medium transition-all ${currentPage === 1 ? "text-gray-400 cursor-not-allowed" : "text-gray-800 hover:bg-white/50 cursor-pointer"
                  }`}
              >
                ←
              </button>

              {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                <button
                  key={pageNum}
                  onClick={() => goToPage(pageNum)}
                  className={`w-9 h-9 flex items-center justify-center rounded-full text-sm font-medium transition-all ${pageNum === currentPage ? "bg-black text-white shadow-lg" : "text-gray-800 hover:bg-white/50 cursor-pointer"
                    }`}
                >
                  {pageNum}
                </button>
              ))}

              <button
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                className={`w-9 h-9 flex items-center justify-center rounded-full text-sm font-medium transition-all ${currentPage === totalPages ? "text-gray-400 cursor-not-allowed" : "text-gray-800 hover:bg-white/50 cursor-pointer"
                  }`}
              >
                →
              </button>
            </div>
          )}
        </div>

        <div className="fixed bottom-0 left-0 sm:left-[280px] w-full sm:w-[calc(100%-280px)] bg-white/95 backdrop-blur-md border-t border-gray-200 p-3 sm:p-4 shadow-xl">
          <form onSubmit={handleCreatePost}>
            <textarea
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="What's on your mind?"
              className="w-full p-3 border border-gray-300 rounded-lg mb-3 text-gray-950 focus:outline-none focus:border-gray-950"
              rows="2"
            />

            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-3">
              <div>
                <label className="px-3 py-2 bg-black text-white hover:bg-gray-300 rounded cursor-pointer text-sm font-medium transition-colors">
                  Choose file
                  <input type="file" accept="image/*" onChange={(e) => setNewPostImage(e.target.files[0])} className="hidden" />
                </label>
                <span className="text-xs text-gray-500 ml-5">{newPostImage ? newPostImage.name : "No file chosen"}</span>
              </div>

              <button type="submit" className="px-4 py-2 bg-black hover:bg-gray-900 text-white rounded-lg font-medium transition-colors w-full sm:w-auto">
                Post
              </button>
            </div>
          </form>
        </div>
      </div>

      <ToastContainer />
    </>
  );
}
