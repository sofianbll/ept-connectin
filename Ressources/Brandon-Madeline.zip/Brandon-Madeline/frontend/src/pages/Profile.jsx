import SideBar from "../components/Sidebar";
import { useState, useEffect, useRef } from "react";
import Sky from "../assets/sky.jpg";
import api from "../services/api";
import { ToastContainer, toast, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const INPUT_CLASS = "bg-transparent text-gray-700/80 placeholder-gray-700/80 outline-none text-sm w-full h-full pr-6";
const INPUT_WRAP =
  "flex items-center w-full bg-transparent shadow-lg border border-gray-300/60 h-12 rounded-full overflow-hidden pl-6 gap-2 mt-4";
const BTN_CLASS =
  "mt-6 w-full h-11 rounded-full shadow-lg text-white bg-black hover:opacity-80 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed";
const DANGER_BTN_CLASS = "mt-6 w-full h-11 rounded-full shadow-lg text-white bg-red-600 hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed";
const SECTION_CLASS = "bg-white/20 backdrop-blur-sm border border-white/30 rounded-2xl p-6 shadow-xl mb-6";

const toastError = {
  position: "top-center",
  autoClose: 5000,
  hideProgressBar: false,
  closeOnClick: false,
  pauseOnHover: true,
  draggable: true,
  theme: "light",
  transition: Slide,
};
const toastSuccess = {
  position: "top-center",
  autoClose: 3000,
  hideProgressBar: false,
  closeOnClick: false,
  pauseOnHover: true,
  draggable: true,
  theme: "dark",
  transition: Slide,
};

export default function Profile() {
  const [user, setUser] = useState(null);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [avatar, setAvatar] = useState(null);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirm, setNewPasswordConfirm] = useState("");
  const [loadingProfile, setLoadingProfile] = useState(false);
  const [loadingPassword, setLoadingPassword] = useState(false);
  const [loadingDelete, setLoadingDelete] = useState(false);
  const [deleteChoice, setDeleteChoice] = useState("delete-content"); // "delete-content" | "keep-content"
  const fileInputRef = useRef(null);

  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  const fetchUser = async () => {
    try {
      const response = await api.get("/me");
      setUser(response.data.user);
      setFirstName(response.data.user.first_name);
      setLastName(response.data.user.last_name);
      setEmail(response.data.user.email);
    } catch (error) {
      console.error("Error loading user", error);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setAvatar(file);
      const reader = new FileReader();
      reader.onloadend = () => setAvatarPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const clearAvatar = () => {
    setAvatar(null);
    setAvatarPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  // Handle profile update
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!firstName || !lastName || !email) {
      toast.error("Please fill in all fields", toastError);
      return;
    }
    if (!emailRegex.test(email)) {
      toast.error("Please enter a valid email", toastError);
      return;
    }
    try {
      setLoadingProfile(true);
      const formData = new FormData();
      formData.append("_method", "PUT");
      formData.append("first_name", firstName);
      formData.append("last_name", lastName);
      formData.append("email", email);
      if (avatar) formData.append("avatar", avatar);
      await api.post("/me", formData);
      clearAvatar();
      toast.success("Profile updated successfully!", toastSuccess);
      await fetchUser();
    } catch (error) {
      toast.error(error.response?.data?.message || "Error updating profile", toastError);
    } finally {
      setLoadingProfile(false);
    }
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !newPasswordConfirm) {
      toast.error("Please fill in all password fields", toastError);
      return;
    }
    if (newPassword !== newPasswordConfirm) {
      toast.error("New passwords do not match", toastError);
      return;
    }
    if (newPassword.length < 8) {
      toast.error("Password must be at least 8 characters", toastError);
      return;
    }
    try {
      setLoadingPassword(true);
      await api.put("/me/password", {
        current_password: currentPassword,
        new_password: newPassword,
        new_password_confirmation: newPasswordConfirm,
      });
      setCurrentPassword("");
      setNewPassword("");
      setNewPasswordConfirm("");
      toast.success("Password changed successfully!", toastSuccess);
    } catch (error) {
      toast.error(error.response?.data?.message || "Error changing password", toastError);
    } finally {
      setLoadingPassword(false);
    }
  };
const handleDeleteAccount = async () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone!")) {
      try {
        setLoadingDelete(true);
        await api.delete("/me", {
          data: { delete_content: deleteChoice === "delete-content" },
        });
        toast.success("Account deleted successfully!", toastSuccess);
        setTimeout(() => {
          localStorage.removeItem("token");
          window.location.href = "/register";
        }, 2000);
      } catch (error) {
        console.error("Error deleting account", error);
        toast.error("Error deleting account", toastError);
        setLoadingDelete(false);
      }
    }
  };

  
  return (
    <>
      <img className="h-screen w-screen" src={Sky} alt="picture of a rose cloudy blue sky" />
      <div className="absolute top-0 left-0 backdrop-blur-3xl w-screen h-full flex justify-center text-center">
        <SideBar />

        <div className="h-screen w-2xl md:min-w-xl overflow-y-scroll py-10 px-6">
          <h2 className="text-2xl font-bold mb-8 text-gray-900">Profile Management</h2>

          {/* Update Profile */}
          <div className={SECTION_CLASS}>
            <h3 className="text-left font-semibold text-gray-800 mb-1">Update Profile</h3>
            <p className="text-left text-xs text-gray-700 mb-2">Edit your personal information</p>
            <hr className="border-gray-300/50 mb-4" />

            {/* Avatar */}
            <div className="flex flex-col items-center mb-6">
              <div
                className="relative w-24 h-24 rounded-full overflow-hidden border-2 border-white/50 shadow-lg cursor-pointer group"
                onClick={() => fileInputRef.current?.click()}
              >
                {avatarPreview || user?.avatar ? (
                  <img
                    src={avatarPreview || user.avatar}
                    alt="Avatar"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-gray-300/50 flex items-center justify-center text-3xl text-gray-700">
                    {firstName?.[0]?.toUpperCase() || "?"}
                  </div>
                )}
                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                  </svg>
                </div>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif"
                onChange={handleAvatarChange}
                className="hidden"
              />
              <p className="text-xs text-gray-700 mt-2">Click to change avatar</p>
              {avatar && (
                <button type="button" onClick={clearAvatar} className="text-xs text-red-500 hover:text-red-700 mt-1">
                  Remove selection
                </button>
              )}
            </div>

            <form onSubmit={handleSubmit}>
              <div className={INPUT_WRAP}>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="First Name"
                  className={INPUT_CLASS}
                />
              </div>
              <div className={INPUT_WRAP}>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="Last Name"
                  className={INPUT_CLASS}
                />
              </div>
              <div className={INPUT_WRAP}>
                <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className={INPUT_CLASS} />
              </div>
              <button type="submit" disabled={loadingProfile} className={BTN_CLASS}>
                {loadingProfile ? "Saving..." : "Save changes"}
              </button>
            </form>
          </div>

          {/* Change Password */}
          <div className={SECTION_CLASS}>
            <h3 className="text-left font-semibold text-gray-800 mb-1">Change Password</h3>
            <p className="text-left text-xs text-gray-700 mb-2">Choose a strong password of at least 8 characters</p>
            <hr className="border-gray-300/50 mb-4" />
            <form onSubmit={handleChangePassword}>
              <div className={INPUT_WRAP}>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Current Password"
                  className={INPUT_CLASS}
                />
              </div>
              <div className={INPUT_WRAP}>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="New Password"
                  className={INPUT_CLASS}
                />
              </div>
              <div className={INPUT_WRAP}>
                <input
                  type="password"
                  value={newPasswordConfirm}
                  onChange={(e) => setNewPasswordConfirm(e.target.value)}
                  placeholder="Confirm New Password"
                  className={INPUT_CLASS}
                />
              </div>
              <button type="submit" disabled={loadingPassword} className={BTN_CLASS}>
                {loadingPassword ? "Updating..." : "Change Password"}
              </button>
            </form>
          </div>

          {/* Delete Account */}
          <div className={`${SECTION_CLASS} border-red-500/30 bg-red-500/10`}>
            <h3 className="text-left font-semibold text-red-600 mb-1">Delete Account</h3>

            <div className="flex flex-col gap-2 mb-4">
              <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                <input
                  type="radio"
                  name="deleteChoice"
                  value="delete-content"
                  checked={deleteChoice === "delete-content"}
                  onChange={(e) => setDeleteChoice(e.target.value)}
                  className="accent-red-600"
                />
                Delete my account and all my posts/comments
              </label>
              <label className="flex items-center gap-2 cursor-pointer text-sm text-gray-700">
                <input
                  type="radio"
                  name="deleteChoice"
                  value="keep-content"
                  checked={deleteChoice === "keep-content"}
                  onChange={(e) => setDeleteChoice(e.target.value)}
                  className="accent-red-600"
                />
                Delete my account but keep my content (anonymized)
              </label>
            </div>

            <p className="text-left text-xs text-red-400 mb-2">Permanently delete your account and all of your content.</p>
            <hr className="border-red-300/30 mb-4" />
            <button
              type="button"
              onClick={handleDeleteAccount}
              disabled={loadingDelete}
              className={DANGER_BTN_CLASS}
            >
              {loadingDelete ? "Deleting..." : "Delete Account"}
            </button>
          </div>
        </div>
      </div>

      <ToastContainer />
    </>
  );
}
