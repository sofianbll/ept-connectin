import { createContext, useContext, useState, useEffect } from "react";
import api from "../services/api";

// The goal of this file is to create a context for authentication,
// which will allow us to manage user authentication state and actions (like login, register, logout)
// across the entire application without having to pass props down manually at every level.
// This context will provide a way to access the current user, token, loading state,
// and authentication functions from any component that needs it.

const AuthContext = createContext();

// The AuthProvider component will wrap the part of our app that needs access to authentication state.

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("token"));
  const [loading, setLoading] = useState(true);

  // useEffect is used to check if the user is already authenticated
  // when the component mounts or when the token changes.
  // It checks if there's a token in localStorage, and if so, it tries to fetch the current user's data.
  // If the token is valid, it sets the user state. If not, it clears the token and user state.
  useEffect(() => {
    const checkAuth = async () => {
      if (token) {
        try {
          const response = await api.get("/me");
          setUser(response.data.user);
        } catch (error) {
          console.error("Erreur lors de la vérification de l'auth:", error);
          localStorage.removeItem("token");
          setToken(null);
        }
      }
      setLoading(false);
    };

    // Call the checkAuth function to verify authentication status on component mount or when token changes
    // This ensures that if the user refreshes the page or comes back to the app,
    // we check if they are still authenticated. Without this, the app wouldn't know
    // if the user is logged in or not until they try to access a protected route.
    checkAuth();
  }, [token]);

  // The login function takes an email and password, sends a request to the backend to authenticate the user,
  // and if successful, it stores the returned token and user data in state and localStorage.

  const login = async (email, password) => {
    const response = await api.post("/login", { email, password });
    const { token: newToken, user: userData } = response.data;
    localStorage.setItem("token", newToken);
    setToken(newToken);
    setUser(userData);
    return response.data;
  };

  // The register function takes user details, sends a request to the backend to create a new user,
  // and if successful, it behaves similarly to login by storing the token and user data.

  const register = async (firstName, lastName, email, password) => {
    const response = await api.post("/register", {
      first_name: firstName,
      last_name: lastName,
      email,
      password,
      password_confirmation: password,
    });
    const { token: newToken, user: userData } = response.data;
    localStorage.setItem("token", newToken);
    setToken(newToken);
    setUser(userData);
    return response.data;
  };

  // The logout function sends a request to the backend to invalidate the token,
  // and then it clears the token and user data from state and localStorage.

  const logout = async () => {
    try {
      await api.post("/logout");
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error);
    }
    localStorage.removeItem("token");
    setToken(null);
    setUser(null);
  };

  const value = {
    user,
    token,
    loading,
    login,
    register,
    logout,
  };

  //Transfers the authentication state and functions to the AuthContext.Provider,
  // making them available to any component that consumes this context.
  // Basically, this allows us to access the current user, token, loading state,
  // and authentication functions from any component that is wrapped by AuthProvider
  // without having to pass them down to each component.
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// The useAuth function is used to access the authentication context from any component.
// It checks if the context is available, without this, if we try to use the useAuth hook
// outside of an AuthProvider, it will throw an error.
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth doit être utilisé dans un AuthProvider");
  }
  return context;
}
