import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import WhiteLogo from '../assets/whiteci.png';
import { useState, useEffect } from "react";

export default function SideBar() {
   const { logout } = useAuth();
   const navigate = useNavigate();

   const [isOpen, setIsOpen] = useState(false);
   const toggleSidebar = () => setIsOpen((prev) => !prev);
   const closeSidebar = () => setIsOpen(false);

   useEffect(() => {
      const handleResize = () => {
         if (window.innerWidth >= 640) closeSidebar();
      };
      window.addEventListener("resize", handleResize);
      return () => window.removeEventListener("resize", handleResize);
   }, []);

   const handleLogout = async () => {
      await logout();
      navigate("/login");
   };

   
   return (
      <>
      <button
        onClick={toggleSidebar}
        className="fixed top-4 left-4 z-50 p-2 rounded-md bg-gray-800 text-gray-200 md:hidden sm:hidden"
        aria-label="Open Menu"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 6h16M4 12h16M4 18h16"
          />
        </svg>
      </button>

      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 md:hidden sm:hidden"
          onClick={closeSidebar}
          aria-hidden="true"
        />
      )}

         <aside
  id="sidebar"
  className={`
    fixed top-0 left-0 bottom-0 z-50
    w-[280px]
    bg-black
    transition-transform duration-300
    ${isOpen ? "translate-x-0" : "-translate-x-full"}
    sm:translate-x-0
  `}
  aria-label="Sidebar"
>

         <button
          type="button"
          className="absolute top-4 right-4 p-2 rounded-md bg-gray-800 text-gray-200 sm:hidden"
          onClick={closeSidebar}
          aria-label="Close menu"
        >
          <svg
            className="w-5 h-5"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>

            <div className="h-full px-3 py-5 overflow-y-auto bg-black">

               <div className="flex items-center space-x-2">
            <img src={WhiteLogo} alt="Logo" className="h-20 w-20" />
            <span className="text-white text-lg font-semibold whitespace-nowrap">
              CONNECT'IN
            </span>
          </div>


               <div className="mt-8 ml-3 mr-3 bg-gray-950 border border-gray-700 rounded-xl">
                  <Link to="/Feed" className="block hover:text-cyan-300">
                     <div className="flex items-center pl-7 py-5 text-body rounded-base">

                        <svg
                           className="text-white fill-current not-only:w-5 h-5 transition duration-75 group-hover:text-fg-brand"
                           aria-hidden="true"
                           xmlns="http://www.w3.org/2000/svg"
                           width="24"
                           height="24"
                           fill="none"
                           viewBox="0 0 24 24"
                        >
                           <path
                              stroke="currentColor"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M10 6.025A7.5 7.5 0 1 0 17.975 14H10V6.025Z"
                           />
                           <path
                              stroke="currentColor"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="2"
                              d="M13.5 3c-.169 0-.334.014-.5.025V11h7.975c.011-.166.025-.331.025-.5A7.5 7.5 0 0 0 13.5 3Z"
                           />
                        </svg>

                        <span className="ms-3 text-lg text-amber-50">Feed</span>

                     </div></Link>

                  <div className="border-b border-gray-700"></div>

                  <Link to="/Profile">
                     <div className="flex items-center pl-7 py-5 text-body rounded-base">
                        <svg
                           className="text-white fill-current shrink-0 w-5 h-5 transition duration-75 group-hover:text-fg-brand"
                           aria-hidden="true"
                           xmlns="http://www.w3.org/2000/svg"
                           width="24"
                           height="24"
                           fill="none"
                           viewBox="0 0 24 24"
                        >
                           <path
                              stroke="currentColor"
                              strokeLinecap="round"
                              strokeWidth="2"
                              d="M16 19h4a1 1 0 0 0 1-1v-1a3 3 0 0 0-3-3h-2m-2.236-4a3 3 0 1 0 0-4M3 18v-1a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1Zm8-10a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                           />
                        </svg>

                        <span className="ms-3 text-amber-50 text-lg">Profile</span>

                     </div>
                  </Link>

               </div>

            </div>

            <div className="absolute bottom-5 left-5" onClick={handleLogout}>
               <button>
                  <span className="flex items-center px-2 py-1.5 text-amber-50 text-body rounded-base text-lg">
                     <svg className="text-white fill-current shrink-0 w-5 h-5 mr-5 transition duration-75 group-hover:text-fg-brand" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        fill="none"
                        viewBox="0 0 24 24"
                     >
                        <path
                           stroke="currentColor"
                           strokeLinecap="round"
                           strokeLinejoin="round"
                           strokeWidth="2"
                           d="M16 12H4m12 0-4 4m4-4-4-4m3-4h2a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3h-2"
                        />
                     </svg>
                     Sign Out
                  </span>
               </button>
            </div>

         </aside>

         <div className="p-4 sm:ml-[280px] mt-14"></div>
      </>
   );
}
