import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Feed from "./pages/Feed";
import Profile from "./pages/Profile";
import PrivateRoute from "./components/PrivateRoute";
import PublicRoute from "./components/PublicRoute";

// Files used in this component:
// - src/context/AuthContext.jsx: provides the authentication context and functions
// for login, register, and logout.
// - src/pages/Login.jsx: the login page component where users can enter their credentials to log in.
// - src/pages/Register.jsx: the registration page component where new users can sign up.
// - src/pages/Feed.jsx: the main feed page that shows posts, accessible only to authenticated users.
// - src/pages/Profile.jsx: the user profile page, also accessible only to authenticated users.
// - src/components/PrivateRoute.jsx: a component that protects routes that require authentication.
// - src/components/PublicRoute.jsx: a component that restricts access to routes for authenticated users.

// The App component sets up the routing for the application and wraps it with the AuthProvider
// to provide authentication state and functions to all components in the app. It defines
// routes for login, registration, feed, and profile pages, using PrivateRoute and PublicRoute
// to control access based on authentication status.

function AppRoutes() {
  return (
    <Routes>
      <Route
        path="/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />
      <Route
        path="/register"
        element={
          <PublicRoute>
            <Register />
          </PublicRoute>
        }
      />
      <Route
        path="/"
        element={
          <PrivateRoute>
            <Feed />
          </PrivateRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <PrivateRoute>
            <Profile />
          </PrivateRoute>
        }
      />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
