import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import "./main.css";
import App from "./App.jsx";

// Files used in this component:
// - src/App.jsx: used inside the StrictMode wrapper to set up routing and authentication context
// for the app.

// The css here is imported to apply global styles to the application.

// The main entry point of our application.
// It imports the necessary modules and renders the App component
// inside a StrictMode wrapper for highlighting potential problems in the application.
// The App component is where we set up our routing and authentication context,
// allowing us to manage user authentication state across the entire app.

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
